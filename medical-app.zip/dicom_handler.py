"""
DICOM ファイル処理モジュール
pydicom を使用して DICOM ファイルの読込みと3次元データの処理を行う
"""

import numpy as np
from pydicom import dcmread
from pathlib import Path
from typing import Optional, Tuple


class DICOMHandler:
    """DICOM ファイルを読込み、処理するクラス"""
    
    def __init__(self):
        self.volume = None  # 3次元ボリュームデータ (Z, Y, X)
        self.slices = []    # スライスデータのリスト
        self.spacing = (1.0, 1.0, 1.0)  # voxel spacing (Z, Y, X)
        self.patient_name = ""
        
    def load_dicom_series(self, directory_path: str) -> bool:
        """
        DICOM シリーズを読込み、3次元ボリュームを構築
        
        Args:
            directory_path: DICOM ファイルが格納されているディレクトリ
            
        Returns:
            bool: 読込み成功時 True、失敗時 False
        """
        try:
            dir_path = Path(directory_path)
            dicom_files = list(dir_path.glob('*.dcm')) + list(dir_path.glob('*.DCM'))
            
            if not dicom_files:
                print(f"DICOM ファイルが見つかりません: {directory_path}")
                return False
            
            # DICOM ファイルを読込み
            self.slices = []
            for file_path in dicom_files:
                try:
                    ds = dcmread(str(file_path))
                    self.slices.append(ds)
                except Exception as e:
                    print(f"DICOM 読込みエラー {file_path}: {e}")
                    continue
            
            if not self.slices:
                print("有効な DICOM ファイルがありません")
                return False
            
            # スライスをZ位置でソート
            self.slices.sort(key=lambda s: float(s.ImagePositionPatient[2]))
            
            # パラメータを取得
            self.patient_name = str(self.slices[0].PatientName) if hasattr(self.slices[0], 'PatientName') else "Unknown"
            
            # voxel spacing を取得
            pixel_spacing = self.slices[0].PixelSpacing
            slice_thickness = float(self.slices[0].SliceThickness) if hasattr(self.slices[0], 'SliceThickness') else 1.0
            self.spacing = (slice_thickness, float(pixel_spacing[0]), float(pixel_spacing[1]))
            
            # 3次元ボリュームを構築
            self._build_volume()
            
            return True
            
        except Exception as e:
            print(f"DICOM シリーズ読込みエラー: {e}")
            return False
    
    def load_single_dicom(self, file_path: str) -> bool:
        """
        単一の DICOM ファイルを読込み
        
        Args:
            file_path: DICOM ファイルのパス
            
        Returns:
            bool: 読込み成功時 True、失敗時 False
        """
        try:
            ds = dcmread(file_path)
            self.slices = [ds]
            self.patient_name = str(ds.PatientName) if hasattr(ds, 'PatientName') else "Unknown"
            
            # voxel spacing を取得
            pixel_spacing = ds.PixelSpacing
            slice_thickness = float(ds.SliceThickness) if hasattr(ds, 'SliceThickness') else 1.0
            self.spacing = (slice_thickness, float(pixel_spacing[0]), float(pixel_spacing[1]))
            
            # 3次元ボリュームを構築
            self._build_volume()
            
            return True
            
        except Exception as e:
            print(f"DICOM ファイル読込みエラー: {e}")
            return False
    
    def _build_volume(self):
        """DICOM スライスから3次元ボリュームを構築"""
        if not self.slices:
            return
        
        # 最初のスライスから画像サイズを取得
        rows = self.slices[0].Rows
        cols = self.slices[0].Columns
        num_slices = len(self.slices)
        
        # 3次元配列を初期化
        self.volume = np.zeros((num_slices, rows, cols), dtype=np.float32)
        
        # ピクセルデータをボリュームに詰める
        for i, ds in enumerate(self.slices):
            pixel_array = ds.pixel_array.astype(np.float32)
            
            # Hounsfield Units に変換 (CT の場合)
            if hasattr(ds, 'RescaleIntercept') and hasattr(ds, 'RescaleSlope'):
                pixel_array = pixel_array * float(ds.RescaleSlope) + float(ds.RescaleIntercept)
            
            self.volume[i] = pixel_array
    
    def get_volume_shape(self) -> Tuple[int, int, int]:
        """
        ボリュームのシェイプを取得
        
        Returns:
            Tuple[int, int, int]: (Z, Y, X) のシェイプ
        """
        if self.volume is None:
            return (0, 0, 0)
        return self.volume.shape
    
    def get_axial_slice(self, z_index: int) -> Optional[np.ndarray]:
        """
        Axial（軸性）スライスを取得
        
        Args:
            z_index: Z インデックス
            
        Returns:
            np.ndarray: スライス画像
        """
        if self.volume is None or z_index < 0 or z_index >= self.volume.shape[0]:
            return None
        return self.volume[z_index, :, :]
    
    def get_coronal_slice(self, y_index: int) -> Optional[np.ndarray]:
        """
        Coronal（冠状）スライスを取得
        
        Args:
            y_index: Y インデックス
            
        Returns:
            np.ndarray: スライス画像
        """
        if self.volume is None or y_index < 0 or y_index >= self.volume.shape[1]:
            return None
        return self.volume[:, y_index, :]
    
    def get_sagittal_slice(self, x_index: int) -> Optional[np.ndarray]:
        """
        Sagittal（矢状）スライスを取得
        
        Args:
            x_index: X インデックス
            
        Returns:
            np.ndarray: スライス画像
        """
        if self.volume is None or x_index < 0 or x_index >= self.volume.shape[2]:
            return None
        return self.volume[:, :, x_index]
    
    def apply_window(self, image: np.ndarray, window_level: float, window_width: float) -> np.ndarray:
        """
        Window/Level を適用して画像を正規化
        
        Args:
            image: 入力画像
            window_level: Window Level (WL)
            window_width: Window Width (WW)
            
        Returns:
            np.ndarray: 正規化された画像 (0-255)
        """
        lower = window_level - window_width / 2
        upper = window_level + window_width / 2
        
        # クリッピング
        image_clipped = np.clip(image, lower, upper)
        
        # 正規化
        image_normalized = ((image_clipped - lower) / (upper - lower) * 255).astype(np.uint8)
        
        return image_normalized
