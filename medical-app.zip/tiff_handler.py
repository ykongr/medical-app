"""
TIFF 画像シリーズ処理モジュール
連続TIFF画像を読込み、3次元ボリュームデータを構築
"""

import numpy as np
from PIL import Image
from pathlib import Path
from typing import Optional, Tuple, List
import os
import re


def natural_sort_key(path):
    """
    自然順序ソート用のキー関数
    "slice_2.tif" が "slice_10.tif" の前に来るようにする
    """
    return [int(text) if text.isdigit() else text.lower()
            for text in re.split('([0-9]+)', str(path.name))]


class TIFFHandler:
    """TIFF 画像シリーズを読込み、処理するクラス"""
    
    def __init__(self):
        self.volume = None  # 3次元ボリュームデータ (Z, Y, X)
        self.file_paths = []  # TIFFファイルパスのリスト
        self.spacing = (1.0, 1.0, 1.0)  # voxel spacing (Z, Y, X)
        self.series_name = ""
    
    @property
    def volume_data(self) -> Optional[np.ndarray]:
        """ボリュームデータへのアクセス用プロパティ"""
        return self.volume
        
    def load_single_tiff(self, file_path: str) -> bool:
        """
        単一のマルチページTIFF ファイルを読込み（lung_only.tifなど）
        
        Args:
            file_path: TIFF ファイルのパス
            
        Returns:
            bool: 読込み成功時 True、失敗時 False
        """
        try:
            img = Image.open(file_path)
            self.series_name = Path(file_path).stem
            
            # フレーム数を数える
            frame_count = 1
            try:
                while True:
                    img.seek(frame_count)
                    frame_count += 1
            except EOFError:
                pass
            
            print(f"マルチページTIFF: {frame_count} フレーム検出")
            
            # 最初のフレームを読んでサイズを取得
            img.seek(0)
            first_array = np.array(img)
            
            rows, cols = first_array.shape[:2]
            num_slices = frame_count
            
            print(f"画像サイズ: {rows} × {cols}, スライス数: {num_slices}")
            
            # 3次元配列を初期化
            if len(first_array.shape) == 2:
                # グレースケール画像
                self.volume = np.zeros((num_slices, rows, cols), dtype=np.float32)
            else:
                # カラー画像の場合はグレースケールに変換
                self.volume = np.zeros((num_slices, rows, cols), dtype=np.float32)
            
            # 各フレームを読み込み
            for i in range(num_slices):
                img.seek(i)
                img_array = np.array(img)
                
                # カラー画像の場合はグレースケールに変換
                if len(img_array.shape) == 3:
                    img_array = np.mean(img_array, axis=2)
                
                self.volume[i] = img_array.astype(np.float32)
                
                if (i + 1) % 10 == 0:
                    print(f"読込み中... {i + 1}/{num_slices}")
            
            print(f"マルチページTIFFの読込みが完了しました")
            return True
            
        except Exception as e:
            print(f"マルチページTIFF読込みエラー: {e}")
            return False
    
    def load_tiff_series(self, directory_path: str) -> bool:
        """
        TIFF シリーズを読込み、3次元ボリュームを構築
        ディレクトリまたは単一のマルチページTIFFファイルに対応
        
        Args:
            directory_path: TIFF ファイルが格納されているディレクトリ、または単一のTIFFファイルパス
            
        Returns:
            bool: 読込み成功時 True、失敗時 False
        """
        # パスがファイルかディレクトリかを判定
        path = Path(directory_path)
        
        # 単一ファイルの場合
        if path.is_file():
            return self.load_single_tiff(str(path))
        
        # ディレクトリの場合
        try:
            dir_path = Path(directory_path)
            
            # TIFFファイルを検索
            tiff_files = []
            for ext in ['*.tif', '*.tiff', '*.TIF', '*.TIFF']:
                tiff_files.extend(list(dir_path.glob(ext)))
            
            if not tiff_files:
                print(f"TIFF ファイルが見つかりません: {directory_path}")
                return False
            
            # 単一のマルチページTIFFファイルの場合
            if len(tiff_files) == 1:
                return self.load_single_tiff(str(tiff_files[0]))
            
            # ファイル名でソート（自然順序）
            tiff_files.sort(key=natural_sort_key)
            self.file_paths = tiff_files
            self.series_name = dir_path.name
            
            print(f"{len(tiff_files)} 枚の TIFF ファイルを検出しました")
            
            # 最初の画像を読み込んでサイズを取得
            first_img = Image.open(str(tiff_files[0]))
            first_array = np.array(first_img)
            
            rows, cols = first_array.shape[:2]
            num_slices = len(tiff_files)
            
            print(f"画像サイズ: {rows} × {cols}, スライス数: {num_slices}")
            
            # 3次元配列を初期化
            if len(first_array.shape) == 2:
                # グレースケール画像
                self.volume = np.zeros((num_slices, rows, cols), dtype=np.float32)
            else:
                # カラー画像の場合はグレースケールに変換
                self.volume = np.zeros((num_slices, rows, cols), dtype=np.float32)
            
            # 各スライスを読み込み
            for i, file_path in enumerate(tiff_files):
                img = Image.open(str(file_path))
                img_array = np.array(img)
                
                # カラー画像の場合はグレースケールに変換
                if len(img_array.shape) == 3:
                    img_array = np.mean(img_array, axis=2)
                
                self.volume[i] = img_array.astype(np.float32)
                
                if (i + 1) % 10 == 0:
                    print(f"読込み中... {i + 1}/{num_slices}")
            
            print(f"TIFF シリーズの読込みが完了しました")
            return True
            
        except Exception as e:
            print(f"TIFF シリーズ読込みエラー: {e}")
            return False
    
    def get_volume_shape(self) -> Tuple[int, int, int]:
        """
        ボリュームのシェイプを取得
        
        Returns:
            Tuple[int, int, int]: (Z, Y, X) のシェイプ
        """
        if self.volume is None:
            return (0, 0, 0)
        return self.volume.shape
    
    def get_axial_slice(self, z_index: int) -> Optional[np.ndarray]:
        """
        Axial（軸性）スライスを取得
        
        Args:
            z_index: Z インデックス
            
        Returns:
            np.ndarray: スライス画像
        """
        if self.volume is None or z_index < 0 or z_index >= self.volume.shape[0]:
            return None
        return self.volume[z_index, :, :]
    
    def get_coronal_slice(self, y_index: int) -> Optional[np.ndarray]:
        """
        Coronal（冠状）スライスを取得
        
        Args:
            y_index: Y インデックス
            
        Returns:
            np.ndarray: スライス画像
        """
        if self.volume is None or y_index < 0 or y_index >= self.volume.shape[1]:
            return None
        return self.volume[:, y_index, :]
    
    def get_sagittal_slice(self, x_index: int) -> Optional[np.ndarray]:
        """
        Sagittal（矢状）スライスを取得
        
        Args:
            x_index: X インデックス
            
        Returns:
            np.ndarray: スライス画像
        """
        if self.volume is None or x_index < 0 or x_index >= self.volume.shape[2]:
            return None
        return self.volume[:, :, x_index]
    
    def apply_window(self, image: np.ndarray, window_level: float, window_width: float) -> np.ndarray:
        """
        Window/Level を適用して画像を正規化
        
        Args:
            image: 入力画像
            window_level: Window Level (WL)
            window_width: Window Width (WW)
            
        Returns:
            np.ndarray: 正規化された画像 (0-255)
        """
        lower = window_level - window_width / 2
        upper = window_level + window_width / 2
        
        # クリッピング
        image_clipped = np.clip(image, lower, upper)
        
        # 正規化
        if upper > lower:
            image_normalized = ((image_clipped - lower) / (upper - lower) * 255).astype(np.uint8)
        else:
            image_normalized = np.zeros_like(image, dtype=np.uint8)
        
        return image_normalized
    
    def get_volume_data(self) -> Optional[np.ndarray]:
        """
        ボリュームデータを取得
        
        Returns:
            np.ndarray: 3次元ボリュームデータ
        """
        return self.volume
