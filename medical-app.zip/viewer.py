"""
カスタムビューアコンポーネント
Canvas ベースのスライス画像表示ウィジェット
"""

import tkinter as tk
from PIL import Image, ImageTk
import numpy as np
from typing import Callable, Optional, Tuple


class SliceViewer(tk.Canvas):
    """
    スライス画像を表示するカスタム Canvas
    
    他の2つのスライス面の位置を示す線を描画可能
    """
    
    def __init__(self, parent, width=400, height=400, scroll_callback=None, scroll_callback_shift=None, **kwargs):
        """
        初期化
        
        Args:
            parent: 親ウィジェット
            width: キャンバスの幅
            height: キャンバスの高さ
            scroll_callback: スクロール時のコールバック関数
            scroll_callback_shift: Shift+スクロール時のコールバック関数
        """
        super().__init__(parent, width=width, height=height, bg='black', **kwargs)
        
        self.image_data = None
        self.photo_image = None
        self.image_id = None
        self.title_text = ""
        self.title_id = None
        
        # 他の2つのスライス面の位置を示す線
        self.crosshair_lines = []  # (line_id, orientation) のリスト
        
        # 画像表示用の余白
        self.margin = 20
        
        # スクロールコールバック
        self.scroll_callback = scroll_callback
        self.scroll_callback_shift = scroll_callback_shift
        
        # ドラッグ関連の変数
        self.drag_start_y = None
        self.drag_start_x = None
        self.is_dragging = False
        
        # マウスホイールイベントをバインド
        self.bind("<MouseWheel>", self._on_mousewheel)  # Windows 上下
        self.bind("<Shift-MouseWheel>", self._on_mousewheel_shift)  # Windows 左右
        self.bind("<Button-4>", self._on_mousewheel)     # Linux 上
        self.bind("<Button-5>", self._on_mousewheel)     # Linux 下
        self.bind("<Shift-Button-4>", self._on_mousewheel_shift)  # Linux Shift+上
        self.bind("<Shift-Button-5>", self._on_mousewheel_shift)  # Linux Shift+下
        
        # マウスドラッグイベントをバインド
        self.bind("<Button-1>", self._on_mouse_press)      # マウスボタン押下
        self.bind("<B1-Motion>", self._on_mouse_drag)      # ドラッグ中
        self.bind("<ButtonRelease-1>", self._on_mouse_release)  # マウスボタン解放
    
    def _on_mousewheel(self, event):
        """
        マウスホイールイベントハンドラー（上下）
        
        Args:
            event: イベントオブジェクト
        """
        if self.scroll_callback is None:
            return
        
        # スクロール方向を判定
        if event.num == 5 or event.delta < 0:
            # スクロールダウン または マウスホイール下
            direction = -1
        else:
            # スクロールアップ または マウスホイール上
            direction = 1
        
        # このビューア用のスライダーをホイール操作で制御
        self.scroll_callback(direction)
    
    def _on_mousewheel_shift(self, event):
        """
        Shift + マウスホイールイベントハンドラー（左右）
        
        Args:
            event: イベントオブジェクト
        """
        if self.scroll_callback_shift is None:
            return
        
        # スクロール方向を判定
        if event.num == 5 or event.delta < 0:
            # スクロールダウン または マウスホイール下 → 左
            direction = -1
        else:
            # スクロールアップ または マウスホイール上 → 右
            direction = 1
        
        # Shift用スライダーをホイール操作で制御（左右スクロール）
        self.scroll_callback_shift(direction)
    
    def _on_mouse_press(self, event):
        """
        マウスボタン押下イベント
        
        Args:
            event: イベントオブジェクト
        """
        self.is_dragging = True
        self.drag_start_y = event.y
        self.drag_start_x = event.x
    
    def _on_mouse_drag(self, event):
        """
        マウスドラッグイベント
        
        Args:
            event: イベントオブジェクト
        """
        if not self.is_dragging or self.drag_start_y is None or self.drag_start_x is None:
            return
        
        if self.scroll_callback is None:
            return
        
        # ドラッグの移動量を計算（10ピクセルで1スライス移動）
        delta_y = event.y - self.drag_start_y
        delta_x = event.x - self.drag_start_x
        
        threshold = 10
        
        # 上下方向のドラッグ（Z スライダー制御）
        if delta_y > threshold:
            # 下へドラッグ → スライスを上へ（Z 減少）
            self.scroll_callback('z', -1)
            self.drag_start_y = event.y
        elif delta_y < -threshold:
            # 上へドラッグ → スライスを下へ（Z 増加）
            self.scroll_callback('z', 1)
            self.drag_start_y = event.y
        
        # 左右方向のドラッグ（Y スライダー制御）
        if delta_x > threshold:
            # 右へドラッグ → Y スライダーを右へ（Y 増加）
            self.scroll_callback('y', 1)
            self.drag_start_x = event.x
        elif delta_x < -threshold:
            # 左へドラッグ → Y スライダーを左へ（Y 減少）
            self.scroll_callback('y', -1)
            self.drag_start_x = event.x
    
    def _on_mouse_release(self, event):
        """
        マウスボタン解放イベント
        
        Args:
            event: イベントオブジェクト
        """
        self.is_dragging = False
        self.drag_start_y = None
        self.drag_start_x = None
        
    def display_image(self, image: np.ndarray, title: str = ""):
        """
        画像をビューアに表示
        
        Args:
            image: 表示する画像 (uint8, 0-255)
            title: 表示するタイトル
        """
        if image is None or image.size == 0:
            self.clear()
            return
        
        self.image_data = image
        self.title_text = title
        
        # NumPy 配列を PIL Image に変換
        pil_image = Image.fromarray(image, mode='L')
        
        # キャンバスサイズに合わせてリサイズ
        canvas_width = self.winfo_width() - 2 * self.margin
        canvas_height = self.winfo_height() - 2 * self.margin
        
        if canvas_width > 1 and canvas_height > 1:
            pil_image.thumbnail((canvas_width, canvas_height), Image.Resampling.LANCZOS)
            self.photo_image = ImageTk.PhotoImage(pil_image)
            
            # 前の画像を削除
            if self.image_id:
                self.delete(self.image_id)
            
            # 新しい画像を表示 (中央に配置)
            self.image_id = self.create_image(
                self.margin + canvas_width // 2,
                self.margin + canvas_height // 2,
                image=self.photo_image
            )
        
        # クロスヘアをリセット（古い線を削除）
        self.clear_crosshairs()
        
        # タイトルを表示
        if self.title_id:
            self.delete(self.title_id)
        self.title_id = self.create_text(
            10, 10,
            text=title,
            fill='white',
            font=('Arial', 10),
            anchor='nw'
        )
        
        # タグを付けて配置順序を管理
        if self.image_id:
            self.tag_lower(self.image_id)
    
    def add_crosshair(self, position: float, orientation: str, color: str = 'red'):
        """
        クロスヘアライン (他の面の位置を示す線) を追加
        
        Args:
            position: ライン位置 (正規化: 0.0-1.0)
            orientation: ライン方向 ('horizontal' または 'vertical')
            color: ライン色
        """
        # Canvas の幅と高さを取得
        canvas_width = self.winfo_width()
        canvas_height = self.winfo_height()
        
        # Canvas がまだ描画されていない場合はスキップ
        if canvas_width <= 1 or canvas_height <= 1:
            return
        
        # 位置を制約（0.0～1.0）
        position = max(0.0, min(1.0, position))
        
        if orientation == 'horizontal':
            # 水平線
            y = canvas_height * position
            line_id = self.create_line(
                0, y,
                canvas_width, y,
                fill=color, width=2
            )
        elif orientation == 'vertical':
            # 垂直線
            x = canvas_width * position
            line_id = self.create_line(
                x, 0,
                x, canvas_height,
                fill=color, width=2
            )
        else:
            return
        
        self.crosshair_lines.append((line_id, orientation))
    
    def add_position_bar(self, position: float, orientation: str, color: str = 'lime', thickness: int = 3):
        """
        位置を示すバー（太い直線）を追加
        
        Args:
            position: バーの位置 (正規化: 0.0-1.0)
            orientation: バーの方向 ('horizontal' または 'vertical')
            color: バーの色
            thickness: バーの太さ
        """
        # Canvas の幅と高さを取得
        canvas_width = self.winfo_width()
        canvas_height = self.winfo_height()
        
        # Canvas がまだ描画されていない場合はスキップ
        if canvas_width <= 1 or canvas_height <= 1:
            return
        
        # 位置を制約（0.0～1.0）
        position = max(0.0, min(1.0, position))
        
        if orientation == 'horizontal':
            # 水平バー
            y = canvas_height * position
            line_id = self.create_line(
                0, y,
                canvas_width, y,
                fill=color, width=thickness
            )
        elif orientation == 'vertical':
            # 垂直バー
            x = canvas_width * position
            line_id = self.create_line(
                x, 0,
                x, canvas_height,
                fill=color, width=thickness
            )
        else:
            return
        
        self.crosshair_lines.append((line_id, orientation))
    
    def update_crosshair(self, line_id: int, position: float):
        """
        クロスヘアの位置を更新
        
        Args:
            line_id: ラインID
            position: 新しい位置 (正規化: 0.0-1.0)
        """
        try:
            coords = self.coords(line_id)
            if not coords:
                return
            
            canvas_width = self.winfo_width() - 2 * self.margin
            canvas_height = self.winfo_height() - 2 * self.margin
            
            if len(coords) == 4:
                x1, y1, x2, y2 = coords
                
                # 水平線か垂直線かを判定
                if x1 == x2:  # 垂直線
                    new_x = self.margin + canvas_width * position
                    self.coords(line_id, new_x, y1, new_x, y2)
                else:  # 水平線
                    new_y = self.margin + canvas_height * position
                    self.coords(line_id, x1, new_y, x2, new_y)
        except tk.TclError:
            pass
    
    def clear_crosshairs(self):
        """すべてのクロスヘアを削除"""
        for line_id, _ in self.crosshair_lines:
            try:
                self.delete(line_id)
            except tk.TclError:
                pass
        self.crosshair_lines = []
    
    def clear(self):
        """ビューアをクリア"""
        self.delete('all')
        self.image_data = None
        self.photo_image = None
        self.image_id = None
        self.title_text = ""
        self.title_id = None
        self.clear_crosshairs()


class ViewerFrame(tk.Frame):
    """
    3つのスライスビューアを含むフレーム
    レイアウト: 左にAxial（大）、中央にCoronal、右にSagittal
    """
    
    def __init__(self, parent, scroll_callback_z=None, scroll_callback_y=None, scroll_callback_x=None, **kwargs):
        """
        初期化
        
        Args:
            parent: 親ウィジェット
            scroll_callback_z: Z軸スクロールコールバック
            scroll_callback_y: Y軸スクロールコールバック
            scroll_callback_x: X軸スクロールコールバック
        """
        super().__init__(parent, **kwargs)
        
        # 3つのビューアを作成
        # Axial: 左側（大きい）- XY 平面
        # 上下スクロール = Y軸制御（横バーが上下に動く）
        # 左右スクロール = X軸制御（縦バーが左右に動く）
        self.axial_viewer = SliceViewer(self, width=400, height=400, 
                                       scroll_callback=scroll_callback_y,      # 上下→Y
                                       scroll_callback_shift=scroll_callback_x) # 左右→X
        self.axial_viewer.grid(row=0, column=0, padx=2, pady=2, sticky='nsew')
        
        # Coronal: 中央 - ZX 平面
        # 上下スクロール = Z軸制御（横バーが上下に動く）
        # 左右スクロール = X軸制御（縦バーが左右に動く）
        self.coronal_viewer = SliceViewer(self, width=300, height=400,
                                         scroll_callback=scroll_callback_z,      # 上下→Z
                                         scroll_callback_shift=scroll_callback_x) # 左右→X
        self.coronal_viewer.grid(row=0, column=1, padx=2, pady=2, sticky='nsew')
        
        # Sagittal: 右側 - ZY 平面
        # 上下スクロール = Z軸制御（横バーが上下に動く）
        # 左右スクロール = Y軸制御（縦バーが左右に動く）
        self.sagittal_viewer = SliceViewer(self, width=300, height=400,
                                          scroll_callback=scroll_callback_z,      # 上下→Z
                                          scroll_callback_shift=scroll_callback_y) # 左右→Y
        self.sagittal_viewer.grid(row=0, column=2, padx=2, pady=2, sticky='nsew')
        
        # グリッドの重み付け設定（レスポンシブレイアウト）
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=2)  # 左側を大きくする
        self.grid_columnconfigure(1, weight=1)
        self.grid_columnconfigure(2, weight=1)
    
    def update_layout(self):
        """レイアウトを更新 (ウィンドウサイズ変更時に呼出)"""
        self.update_idletasks()
