"""
DICOM ビューアアプリケーション
マルチプレーン（Axial, Coronal, Sagittal）表示と対話的なスライダー操作に対応
"""

import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import numpy as np
from pathlib import Path
from dicom_handler import DICOMHandler
from tiff_handler import TIFFHandler
from viewer import ViewerFrame
from volume_renderer import VolumeRenderer


class DICOMViewerApp:
    """メインアプリケーションクラス"""
    
    def __init__(self, root):
        """
        初期化
        
        Args:
            root: Tkinter ルートウィンドウ
        """
        self.root = root
        self.root.title("DICOM ビューア")
        self.root.geometry("1400x850")  # コンパクトなサイズに調整
        self.root.minsize(1000, 600)  # 最小サイズを設定
        
        self.dicom_handler = DICOMHandler()
        self.tiff_handler = TIFFHandler()
        self.current_handler = None  # 現在使用中のハンドラー
        self.current_z = 0
        self.current_y = 0
        self.current_x = 0
        self.window_level = 40
        self.window_width = 400
        
        self._setup_menu()
        self._setup_ui()
        
    def _setup_menu(self):
        """メニューバーをセットアップ"""
        menubar = tk.Menu(self.root)
        self.root.config(menu=menubar)
        
        # ファイルメニュー
        file_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="ファイル", menu=file_menu)
        file_menu.add_command(label="DICOM ファイルを開く", command=self._open_dicom_file)
        file_menu.add_command(label="DICOM フォルダを開く", command=self._open_dicom_folder)
        file_menu.add_separator()
        file_menu.add_command(label="TIFF ファイルを開く", command=self._open_tiff_file)
        file_menu.add_command(label="TIFF フォルダを開く", command=self._open_tiff_folder)
        file_menu.add_separator()
        file_menu.add_command(label="終了", command=self.root.quit)
        
        # 表示メニュー
        view_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="表示", menu=view_menu)
        view_menu.add_command(label="3D ボリュームレンダリング", command=self._show_3d_volume)
        
        # ヘルプメニュー
        help_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="ヘルプ", menu=help_menu)
        help_menu.add_command(label="操作方法", command=self._show_help)
    
    def _setup_ui(self):
        """ユーザーインターフェースをセットアップ"""
        # メインフレーム
        main_frame = ttk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=3, pady=3)
        
        # 患者情報表示
        info_frame = ttk.LabelFrame(main_frame, text="患者情報", padding=3)
        info_frame.pack(fill=tk.X, pady=(0, 3))
        
        self.patient_name_label = ttk.Label(info_frame, text="患者名: -", font=('Arial', 9))
        self.patient_name_label.pack(side=tk.LEFT, padx=3)
        
        self.volume_info_label = ttk.Label(info_frame, text="ボリュームサイズ: -", font=('Arial', 9))
        self.volume_info_label.pack(side=tk.LEFT, padx=3)
        
        # ビューアフレーム（メインの表示領域）
        viewer_frame = ViewerFrame(main_frame, 
                                  scroll_callback_z=lambda d: self._on_scroll_axis('z', d),
                                  scroll_callback_y=lambda d: self._on_scroll_axis('y', d),
                                  scroll_callback_x=lambda d: self._on_scroll_axis('x', d))
        viewer_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 3))
        self.viewer_frame = viewer_frame
        
        # コントロールパネル（下部）
        control_frame = ttk.LabelFrame(main_frame, text="画像コントロール", padding=5)
        control_frame.pack(fill=tk.X)
        
        # Window/Level コントロール
        wl_frame = ttk.Frame(control_frame)
        wl_frame.pack(fill=tk.X, pady=2)
        
        wl_label = ttk.Label(wl_frame, text="Window Level (WL):", width=15, font=('Arial', 9))
        wl_label.pack(side=tk.LEFT, padx=3)
        
        self.wl_slider = ttk.Scale(
            wl_frame, from_=-100, to=500, orient=tk.HORIZONTAL,
            command=self._on_wl_slider_change
        )
        self.wl_slider.set(self.window_level)
        self.wl_slider.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=3)
        
        self.wl_label_value = ttk.Label(wl_frame, text="40", width=8, font=('Arial', 9))
        self.wl_label_value.pack(side=tk.LEFT, padx=3)
        
        # Window Width コントロール
        ww_frame = ttk.Frame(control_frame)
        ww_frame.pack(fill=tk.X, pady=2)
        
        ww_label = ttk.Label(ww_frame, text="Window Width (WW):", width=15, font=('Arial', 9))
        ww_label.pack(side=tk.LEFT, padx=3)
        
        self.ww_slider = ttk.Scale(
            ww_frame, from_=10, to=2000, orient=tk.HORIZONTAL,
            command=self._on_ww_slider_change
        )
        self.ww_slider.set(self.window_width)
        self.ww_slider.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=3)
        
        self.ww_label_value = ttk.Label(ww_frame, text="400", width=8, font=('Arial', 9))
        self.ww_label_value.pack(side=tk.LEFT, padx=3)
        
        # スライス位置表示（読み取り専用）
        position_frame = ttk.Frame(control_frame)
        position_frame.pack(fill=tk.X, pady=2)
        
        position_label = ttk.Label(position_frame, text="スライス位置:", width=15, font=('Arial', 9))
        position_label.pack(side=tk.LEFT, padx=3)
        
        self.position_display = ttk.Label(position_frame, 
                                         text="Z: 0/0  |  Y: 0/0  |  X: 0/0", 
                                         font=('Arial', 9))
        self.position_display.pack(side=tk.LEFT, padx=3)
    
    def _open_dicom_file(self):
        """DICOM ファイルを開く"""
        file_path = filedialog.askopenfilename(
            title="DICOM ファイルを選択",
            filetypes=[("DICOM files", "*.dcm"), ("All files", "*.*")]
        )
        
        if file_path:
            self._load_dicom(file_path)
    
    def _open_dicom_folder(self):
        """DICOM フォルダを開く"""
        folder_path = filedialog.askdirectory(title="DICOM ファイルが格納されているフォルダを選択")
        
        if folder_path:
            self._load_dicom_series(folder_path)
    
    def _load_dicom(self, file_path: str):
        """
        DICOM ファイルを読込み
        
        Args:
            file_path: DICOM ファイルのパス
        """
        if self.dicom_handler.load_single_dicom(file_path):
            self._update_ui_after_load()
            messagebox.showinfo("成功", "DICOM ファイルを読込みました")
        else:
            messagebox.showerror("エラー", "DICOM ファイルの読込みに失敗しました")
    
    def _load_dicom_series(self, folder_path: str):
        """
        DICOM シリーズを読込み
        
        Args:
            folder_path: フォルダパス
        """
        if self.dicom_handler.load_dicom_series(folder_path):
            self.current_handler = self.dicom_handler
            self._update_ui_after_load()
            messagebox.showinfo("成功", f"DICOM シリーズを読込みました ({len(self.dicom_handler.slices)} スライス)")
        else:
            messagebox.showerror("エラー", "DICOM シリーズの読込みに失敗しました")
    
    def _open_tiff_file(self):
        """単一のマルチページTIFF ファイルを開く"""
        file_path = filedialog.askopenfilename(
            title="TIFF ファイルを選択",
            filetypes=[("TIFF files", "*.tif *.tiff"), ("All files", "*.*")]
        )
        
        if file_path:
            self._load_tiff_series(file_path)
    
    def _open_tiff_folder(self):
        """TIFF フォルダを開く"""
        folder_path = filedialog.askdirectory(title="TIFF ファイルが格納されているフォルダを選択")
        
        if folder_path:
            self._load_tiff_series(folder_path)
    
    def _load_tiff_series(self, path: str):
        """
        TIFF シリーズまたは単一TIFFファイルを読込み
        
        Args:
            path: フォルダパスまたはファイルパス
        """
        if self.tiff_handler.load_tiff_series(path):
            self.current_handler = self.tiff_handler
            
            # スライス数を取得
            z_size, _, _ = self.tiff_handler.get_volume_shape()
            messagebox.showinfo("成功", f"TIFF データを読込みました ({z_size} スライス)\n3Dボリュームレンダリングを表示します")
            
            # 自動的に3D表示を起動
            self._show_3d_volume()
        else:
            messagebox.showerror("エラー", "TIFF データの読込みに失敗しました")
    
    def _show_3d_volume(self):
        """3D ボリュームレンダリングを表示"""
        if self.current_handler is None:
            messagebox.showwarning("警告", "画像データが読み込まれていません")
            return
        
        volume_data = self.current_handler.volume_data
        if volume_data is None:
            messagebox.showwarning("警告", "ボリュームデータが利用できません")
            return
        
        # 3D表示の説明
        result = messagebox.askokcancel(
            "3D ボリュームレンダリング",
            "3DウィンドウをVTKの独自ウィンドウで開きます。\n\n"
            "操作方法:\n"
            "  - 左ドラッグ: 回転\n"
            "  - 中ボタンドラッグ: パン（移動）\n"
            "  - ホイール: ズーム\n"
            "  - 'q'キー: ウィンドウを閉じる\n\n"
            "注意: 3Dウィンドウを閉じるまで、メインウィンドウの操作はできません。"
        )
        
        if result:
            # VolumeRenderer を作成して表示
            renderer = VolumeRenderer(self.root)
            renderer.render_volume(volume_data)
    
    def _update_ui_after_load(self):
        """DICOM 読込み後に UI を更新"""
        self.current_handler = self.dicom_handler
        z_size, y_size, x_size = self.dicom_handler.get_volume_shape()
        
        # 初期位置を設定
        self.current_z = z_size // 2
        self.current_y = y_size // 2
        self.current_x = x_size // 2
        
        # 患者情報を表示
        self.patient_name_label.config(text=f"患者名: {self.dicom_handler.patient_name}")
        self.volume_info_label.config(text=f"ボリュームサイズ: {z_size}×{y_size}×{x_size}")
        
        # スライス位置表示を更新
        self._update_position_display()
        
        # 画像を表示
        self._update_views()
    
    def _update_ui_after_load_tiff(self):
        """TIFF 読込み後に UI を更新"""
        z_size, y_size, x_size = self.tiff_handler.get_volume_shape()
        
        # 初期位置を設定
        self.current_z = z_size // 2
        self.current_y = y_size // 2
        self.current_x = x_size // 2
        
        # 患者情報を表示（TIFFの場合はファイル名表示）
        self.patient_name_label.config(text=f"ファイル名: {self.tiff_handler.series_name}")
        self.volume_info_label.config(text=f"ボリュームサイズ: {z_size}×{y_size}×{x_size}")
        
        # TIFF データの自動 WL/WW 計算（ゼロ値を除外）
        if self.tiff_handler.volume_data is not None:
            data = self.tiff_handler.volume_data
            
            # ゼロでないピクセルのみを使用
            non_zero_data = data[data > 0]
            
            if len(non_zero_data) > 0:
                # ゼロでないピクセルの統計を使用
                data_min = float(non_zero_data.min())
                data_max = float(non_zero_data.max())
                data_mean = float(non_zero_data.mean())
                data_std = float(non_zero_data.std())
            else:
                # すべてゼロの場合は全データの統計を使用
                data_min = float(np.min(data))
                data_max = float(np.max(data))
                data_mean = float(np.mean(data))
                data_std = float(np.std(data))
            
            # WL を平均値、WW を標準偏差の3倍に設定
            self.window_level = data_mean
            self.window_width = max(10, data_std * 3)
            
            # スライダーの範囲を調整
            self.wl_slider.config(from_=data_min, to=data_max)
            self.wl_slider.set(self.window_level)
            if hasattr(self, 'wl_label_value'):
                self.wl_label_value.config(text=f"{self.window_level:.0f}")
            
            self.ww_slider.config(from_=10, to=data_max - data_min)
            self.ww_slider.set(self.window_width)
            if hasattr(self, 'ww_label_value'):
                self.ww_label_value.config(text=f"{self.window_width:.0f}")
        
        # スライス位置表示を更新
        self._update_position_display()
        
        # 画像を表示
        self._update_views()
    
    def _update_position_display(self):
        """スライス位置表示を更新"""
        if self.current_handler is None:
            return
        
        z_size, y_size, x_size = self.current_handler.get_volume_shape()
        if z_size > 0 and y_size > 0 and x_size > 0:
            self.position_display.config(
                text=f"Z: {self.current_z}/{z_size - 1}  |  Y: {self.current_y}/{y_size - 1}  |  X: {self.current_x}/{x_size - 1}"
            )
    
    def _on_wl_slider_change(self, value):
        """Window Level スライダー変更イベント"""
        self.window_level = float(value)
        if hasattr(self, 'wl_label_value'):
            self.wl_label_value.config(text=f"{self.window_level:.0f}")
        self._update_views()
    
    def _on_ww_slider_change(self, value):
        """Window Width スライダー変更イベント"""
        self.window_width = float(value)
        if hasattr(self, 'ww_label_value'):
            self.ww_label_value.config(text=f"{self.window_width:.0f}")
        self._update_views()
    
    def _on_scroll_axis(self, axis: str, direction: int):
        """
        各ビューアでのスクロール処理
        
        Args:
            axis: 軸 ('z', 'y', 'x')
            direction: スクロール方向 (1: 増加、-1: 減少)
        """
        if self.current_handler is None:
            return
        
        z_size, y_size, x_size = self.current_handler.get_volume_shape()
        
        if axis == 'z':
            # Z スライダーを制御
            if z_size <= 0:
                return
            
            step = 1
            new_z = self.current_z + direction * step
            new_z = max(0, min(new_z, z_size - 1))
            
            self.current_z = new_z
        
        elif axis == 'y':
            # Y スライダーを制御
            if y_size <= 0:
                return
            
            step = 1
            new_y = self.current_y + direction * step
            new_y = max(0, min(new_y, y_size - 1))
            
            self.current_y = new_y
        
        elif axis == 'x':
            # X スライダーを制御
            if x_size <= 0:
                return
            
            step = 1
            new_x = self.current_x + direction * step
            new_x = max(0, min(new_x, x_size - 1))
            
            self.current_x = new_x
        
        # スライス位置表示を更新
        self._update_position_display()
        
        # 画像を更新
        self._update_views()
    
    def _update_views(self):
        """すべてのスライス画像を更新"""
        if self.current_handler is None:
            return
        
        z_size, y_size, x_size = self.current_handler.get_volume_shape()
        
        if z_size == 0 or y_size == 0 or x_size == 0:
            return
        
        # 正規化された位置を計算
        z_pos_norm = self.current_z / (z_size - 1) if z_size > 1 else 0.5
        y_pos_norm = self.current_y / (y_size - 1) if y_size > 1 else 0.5
        x_pos_norm = self.current_x / (x_size - 1) if x_size > 1 else 0.5
        
        # Axial スライスを取得して表示（Z 軸のスライス）
        # 左側に表示
        axial_image = self.current_handler.get_axial_slice(self.current_z)
        if axial_image is not None:
            axial_image_8bit = self.current_handler.apply_window(
                axial_image, self.window_level, self.window_width
            )
            self.viewer_frame.axial_viewer.display_image(
                axial_image_8bit,
                f"Axial (XY): Z={self.current_z}/{z_size - 1}"
            )
            
            # Axial は XY 平面を見ているので、Y と X の位置バーを表示
            # Y 方向のバー（水平、Coronal との交線）
            self.viewer_frame.axial_viewer.add_position_bar(y_pos_norm, 'horizontal', 'lime', 3)
            # X 方向のバー（垂直、Sagittal との交線）
            self.viewer_frame.axial_viewer.add_position_bar(x_pos_norm, 'vertical', 'lime', 3)
        
        # Coronal スライスを取得して表示（Y 軸のスライス）
        # 中央に表示
        coronal_image = self.current_handler.get_coronal_slice(self.current_y)
        if coronal_image is not None:
            coronal_image_8bit = self.current_handler.apply_window(
                coronal_image, self.window_level, self.window_width
            )
            self.viewer_frame.coronal_viewer.display_image(
                coronal_image_8bit,
                f"Coronal (ZX): Y={self.current_y}/{y_size - 1}"
            )
            
            # Coronal は ZX 平面を見ているので、Z と X の位置バーを表示
            # Z 方向のバー（水平、Sagittal との交線）
            self.viewer_frame.coronal_viewer.add_position_bar(z_pos_norm, 'horizontal', 'lime', 3)
            # X 方向のバー（垂直、Axial との交線）
            self.viewer_frame.coronal_viewer.add_position_bar(x_pos_norm, 'vertical', 'lime', 3)
        
        # Sagittal スライスを取得して表示（X 軸のスライス）
        # 右側に表示
        sagittal_image = self.current_handler.get_sagittal_slice(self.current_x)
        if sagittal_image is not None:
            sagittal_image_8bit = self.current_handler.apply_window(
                sagittal_image, self.window_level, self.window_width
            )
            self.viewer_frame.sagittal_viewer.display_image(
                sagittal_image_8bit,
                f"Sagittal (ZY): X={self.current_x}/{x_size - 1}"
            )
            
            # Sagittal は ZY 平面を見ているので、Z と Y の位置バーを表示
            # Z 方向のバー（水平、Coronal との交線）
            self.viewer_frame.sagittal_viewer.add_position_bar(z_pos_norm, 'horizontal', 'lime', 3)
            # Y 方向のバー（垂直、Axial との交線）
            self.viewer_frame.sagittal_viewer.add_position_bar(y_pos_norm, 'vertical', 'lime', 3)
        
        # 画面をリフレッシュ
        self.root.update_idletasks()
    
    def _show_help(self):
        """操作方法を表示"""
        help_text = """
DICOM/TIFF ビューア - 操作方法

【メニュー】
- ファイル → DICOM ファイルを開く: 単一の DICOM ファイルを読込み
- ファイル → DICOM フォルダを開く: フォルダ内の DICOM シリーズを読込み
- ファイル → TIFF ファイルを開く: マルチページ TIFF を読込み、自動的に3D表示
- ファイル → TIFF フォルダを開く: TIFF シリーズを読込み、自動的に3D表示
- 表示 → 3D ボリュームレンダリング: DICOM データを 3D 表示

【DICOM 画像操作】
- 各画像上でマウススクロール: その画像に対応する軸のスライスを移動
  - Axial画像: 上下スクロールでY軸、Shift+横スクロールでX軸
  - Coronal画像: 上下スクロールでZ軸、Shift+横スクロールでX軸
  - Sagittal画像: 上下スクロールでZ軸、Shift+横スクロールでY軸
- クロスヘア（ライムグリーン線）が他の2つの面の位置を示します
- Window Level (WL): 画像のコントラスト中心を調整
- Window Width (WW): 画像のコントラスト幅を調整

【3D ボリュームレンダリング】
- マウス左ドラッグ: 回転
- マウス中ボタンドラッグ: パン（移動）
- マウスホイール: ズーム

【TIFF ファイルについて】
- TIFF ファイルは自動的に3Dボリュームレンダリングで表示されます
- マルチページTIFF（lung_only.tifなど）と連続TIFFシリーズの両方に対応
        """
        messagebox.showinfo("操作方法", help_text)


def main():
    """メイン関数"""
    root = tk.Tk()
    app = DICOMViewerApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
