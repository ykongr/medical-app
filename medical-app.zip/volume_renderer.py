"""
3D ボリュームレンダリング モジュール
VTK を使用して3次元ボリュームデータを表示
"""

import numpy as np
import tkinter as tk
from tkinter import ttk
import vtk
from vtk.util import numpy_support


class VolumeRenderer:
    """VTK を使用した3Dボリュームレンダリングクラス"""
    
    def __init__(self, parent_window):
        """
        初期化
        
        Args:
            parent_window: 親ウィンドウ
        """
        self.parent_window = parent_window
        self.window = None
        self.renderer = None
        self.render_window = None
        self.interactor = None
        self.volume = None
        self.volume_property = None
        
    def render_volume(self, volume_data: np.ndarray):
        """
        ボリュームデータを3D表示
        
        Args:
            volume_data: 3次元ボリュームデータ (Z, Y, X)
        """
        if volume_data is None or volume_data.size == 0:
            print("ボリュームデータが空です")
            return
        
        # VTK レンダラーをセットアップ（Tkinterウィンドウなし）
        self._setup_vtk_renderer_standalone(volume_data)
    
    def _setup_vtk_renderer_standalone(self, volume_data):
        """
        VTK レンダラーをスタンドアロンウィンドウでセットアップ
        
        Args:
            volume_data: ボリュームデータ
        """
        print("3Dボリュームレンダリングを準備中...")
        
        # NumPy配列をVTK画像データに変換
        vtk_data_array = numpy_support.numpy_to_vtk(
            volume_data.ravel(), 
            deep=True, 
            array_type=vtk.VTK_FLOAT
        )
        
        # VTK Image Data を作成
        image_data = vtk.vtkImageData()
        image_data.SetDimensions(volume_data.shape[2], volume_data.shape[1], volume_data.shape[0])
        image_data.SetSpacing(1.0, 1.0, 1.0)
        image_data.GetPointData().SetScalars(vtk_data_array)
        
        # ボリュームマッパーを作成
        volume_mapper = vtk.vtkGPUVolumeRayCastMapper()
        volume_mapper.SetInputData(image_data)
        
        # ボリュームプロパティを設定
        self.volume_property = vtk.vtkVolumeProperty()
        self.volume_property.ShadeOn()
        self.volume_property.SetInterpolationTypeToLinear()
        
        # カラー転送関数
        color_func = vtk.vtkColorTransferFunction()
        color_func.AddRGBPoint(0, 0.0, 0.0, 0.0)
        color_func.AddRGBPoint(64, 0.5, 0.0, 0.0)
        color_func.AddRGBPoint(128, 1.0, 0.5, 0.5)
        color_func.AddRGBPoint(192, 1.0, 1.0, 1.0)
        color_func.AddRGBPoint(255, 1.0, 1.0, 1.0)
        
        # 不透明度転送関数
        opacity_func = vtk.vtkPiecewiseFunction()
        opacity_func.AddPoint(0, 0.0)
        opacity_func.AddPoint(64, 0.1)
        opacity_func.AddPoint(128, 0.3)
        opacity_func.AddPoint(192, 0.6)
        opacity_func.AddPoint(255, 0.8)
        
        self.volume_property.SetColor(color_func)
        self.volume_property.SetScalarOpacity(opacity_func)
        
        # ボリュームアクターを作成
        self.volume = vtk.vtkVolume()
        self.volume.SetMapper(volume_mapper)
        self.volume.SetProperty(self.volume_property)
        
        # レンダラーを作成
        self.renderer = vtk.vtkRenderer()
        self.renderer.AddVolume(self.volume)
        self.renderer.SetBackground(0.1, 0.1, 0.2)
        self.renderer.ResetCamera()
        
        # レンダーウィンドウを作成
        self.render_window = vtk.vtkRenderWindow()
        self.render_window.AddRenderer(self.renderer)
        self.render_window.SetSize(800, 600)
        self.render_window.SetWindowName("3D ボリュームレンダリング - lung_only.tif")
        
        # VTK独自のウィンドウで表示
        self.interactor = vtk.vtkRenderWindowInteractor()
        self.interactor.SetRenderWindow(self.render_window)
        
        style = vtk.vtkInteractorStyleTrackballCamera()
        self.interactor.SetInteractorStyle(style)
        
        print("3Dウィンドウを表示中...")
        print("操作方法:")
        print("  - 左ドラッグ: 回転")
        print("  - 中ボタンドラッグ: パン")
        print("  - ホイール: ズーム")
        print("  - 'q'キー: 閉じる")
        
        # ウィンドウを表示してインタラクションを開始
        self.render_window.Render()
        self.interactor.Initialize()
        self.interactor.Start()
    
    def _setup_vtk_renderer(self, parent_frame, volume_data):
        """
        VTK レンダラーをセットアップ（未使用 - スタンドアロンを使用）
        
        Args:
            parent_frame: 親フレーム
            volume_data: ボリュームデータ
        """
        pass
    
    def _setup_controls(self, control_frame):
        """
        コントロールパネルをセットアップ（未使用）
        
        Args:
            control_frame: コントロールフレーム
        """
        pass
    
    def _on_opacity_change(self, value):
        """
        不透明度変更イベント（未使用）
        
        Args:
            value: スライダーの値
        """
        pass
    
    def _reset_camera(self):
        """カメラをリセット（未使用）"""
        pass
